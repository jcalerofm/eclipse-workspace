package com.jnieto.IoC;

public interface CreacionInformes {
  public String getInformes();

}
