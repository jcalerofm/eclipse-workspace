package com.jnieto.IoC;

public class SecretarioEmpleado implements EmpleadosDAM {

  public SecretarioEmpleado(CreacionInformes informeNuevo) {
    this.informeNuevo = informeNuevo;
  }

  @Override
  public String getTareas() {
    return "Gestionar la agenda de los jefes";
  }

  @Override
  public String getInforme() {
    return "Informe generado por el secretario: " + informeNuevo.getInformes();
  }

  public void setInformeNuevo(CreacionInformes informeNuevo) {
    this.informeNuevo = informeNuevo;
  }

  private CreacionInformes informeNuevo;
}
