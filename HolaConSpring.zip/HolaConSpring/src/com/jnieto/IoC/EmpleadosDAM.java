package com.jnieto.IoC;

public interface EmpleadosDAM {
  public String getTareas();
  public String getInforme();
}
