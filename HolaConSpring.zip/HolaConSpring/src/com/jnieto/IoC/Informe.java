package com.jnieto.IoC;

public class Informe implements CreacionInformes {

  @Override
  public String getInformes() {
    return "Es es la presentacion del informe";
  }

}


