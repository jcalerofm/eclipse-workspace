package com.jnieto.IoC;

public class JefeEmpleado implements EmpleadosDAM{
  public JefeEmpleado(CreacionInformes informeNuevo) {
    this.informeNuevo = informeNuevo;
  }

  @Override
  public String getTareas() {
    return "Gestiona la plantilla de la empresa";
  }
  @Override
  public String getInforme() {
    return "Informe generado por el jefe: " + informeNuevo.getInformes();
  }

  private CreacionInformes informeNuevo;

}
