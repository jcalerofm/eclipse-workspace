package com.jnieto.IoC;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UsoEmpleados {

  public static void main(String[] args) {
    // Creamos un contexto, cargamos el xml
    ClassPathXmlApplicationContext contexto = new ClassPathXmlApplicationContext("applicationContext.xml");

    //Pedimos un bean
    EmpleadosDAM jnieto = contexto.getBean("miEmpleado", EmpleadosDAM.class);
    EmpleadosDAM chiqui = contexto.getBean("miSecretarioEmpleado", EmpleadosDAM.class);
    

    System.out.println(jnieto.getTareas());
    System.out.println(jnieto.getInforme());
    System.out.println(chiqui.getTareas());
    System.out.println(chiqui.getInforme());

    contexto.close();

  }


}
