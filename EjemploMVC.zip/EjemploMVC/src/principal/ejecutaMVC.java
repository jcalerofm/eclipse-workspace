package principal;

import javax.swing.*;
import vista.*;

public class ejecutaMVC {
	
	public static void main(String[] args) {
		
		Marco_Aplicacion x = new Marco_Aplicacion();
		x.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		x.setVisible(true);
		
;	}

}
